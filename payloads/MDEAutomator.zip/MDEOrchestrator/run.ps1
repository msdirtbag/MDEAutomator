# MDEOrchestrator Function App
# 0.0.1

using namespace System.Net

param($Request)

try {
    # Extract parameters from the incoming HTTP request
    $TenantId   = Get-RequestParam -Name "TenantId"   -Request $Request
    $Function   = Get-RequestParam -Name "Function"   -Request $Request
    $DeviceIds  = Get-RequestParam -Name "DeviceIds"  -Request $Request
    $allDevices = Get-RequestParam -Name "allDevices" -Request $Request
    $Filter     = Get-RequestParam -Name "Filter"     -Request $Request
    $scriptName = Get-RequestParam -Name "scriptName" -Request $Request
    $filePath   = Get-RequestParam -Name "filePath"   -Request $Request
    $fileName   = Get-RequestParam -Name "fileName"   -Request $Request
    $StorageAccountName = Get-RequestParam -Name "StorageAccountName" -Request $Request

    # Retrieve environment variables for authentication
    $spnId        = [System.Environment]::GetEnvironmentVariable('SPNID', 'Process')
    $keyVaultName = [System.Environment]::GetEnvironmentVariable('AZURE_KEYVAULT', 'Process')
    $token        = Connect-MDE -TenantId $TenantId -SpnId $spnId -keyVaultName $keyVaultName

    # Device discovery: get all or filtered devices if requested
    if ($allDevices -eq $true) {
        Write-Host "Getting all devices"
        $machines = Get-Machines -token $token
        if ($null -ne $machines) {
            $DeviceIds = @($machines | ForEach-Object { $_.Id })
        } else {
            $DeviceIds = @()
        }
        Write-Host "Machines returned: $($machines.Count)"
        Write-Host "DeviceIds: $($DeviceIds -join ' ')"
    }
    elseif ($null -ne $Filter -and $Filter -ne "") {
        Write-Host "Getting devices with filter: $Filter"
        $machines = Get-Machines -token $token -Filter $Filter
        if ($null -ne $machines) {
            $DeviceIds = @($machines | ForEach-Object { $_.Id })
        } else {
            $DeviceIds = @()
        }
        Write-Host "Machines returned: $($machines.Count)"
        Write-Host "DeviceIds: $($DeviceIds -join ' ')"
    }

    # Normalize DeviceIds to always be an array of strings
    if ($null -eq $DeviceIds) {
        $DeviceIds = @()
    } elseif ($DeviceIds -is [string]) {
        $DeviceIds = $DeviceIds -split '[\s,;]+' | Where-Object { $_ -ne "" }
    } elseif ($DeviceIds -is [System.Collections.IEnumerable]) {
        $DeviceIds = @($DeviceIds | ForEach-Object { "$_" } | Where-Object { $_ -ne "" })
    } else {
        $DeviceIds = @("$DeviceIds")
    }

    # If no devices to process, return early
    if ($DeviceIds.Count -eq 0) {
        Write-Host "No DeviceIds to process."
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::OK
            Body = "No DeviceIds to process."
        })
        return
    }

    $throttleLimit = 10 # Limit parallelism for Azure Function best practices

    # Main orchestration: process each device in parallel
    $orchestratorResults = $DeviceIds | ForEach-Object -Parallel {
        param($_)
        $DeviceId = $_
        Import-Module "$using:PSScriptRoot\..\MDEAutomator\MDEAutomator.psm1" -Force
        try {
            switch ($using:Function) {
                "InvokeLRScript" {
                    if (-not $using:scriptName) { throw "scriptName parameter is required for Invoke-LRScript" }
                    $output = @()
                    $results = Invoke-LRScript -token $using:token -DeviceIds @($DeviceId) -scriptName $using:scriptName
                    foreach ($res in $results) {
                        $transcript = $null
                        if ($res.Success -and $res.MachineActionId) {
                            try {
                                $transcriptObj = Get-LiveResponseOutput -machineActionId $res.MachineActionId -token $using:token
                                $transcript = $transcriptObj
                            } catch {
                                $transcript = "Failed to get transcript: $($_.Exception.Message)"
                            }
                        }
                        $output += [PSCustomObject]@{
                            DeviceId        = $res.DeviceId
                            MachineActionId = $res.MachineActionId
                            Success         = $res.Success
                            Transcript      = $transcript
                        }
                    }
                    return $output
                }
                "InvokePutFile" {
                    if (-not $using:fileName) { throw "fileName parameter is required for Invoke-PutFile" }
                    $output = @()
                    $results = Invoke-PutFile -token $using:token -DeviceIds @($DeviceId) -fileName $using:fileName
                    foreach ($res in $results) {
                        $output += $res
                    }
                    return $output
                }
                "InvokeGetFile" {
                    if (-not $using:filePath) { throw "filePath parameter is required for Invoke-GetFile" }
                    $output = @()
                    $results = Invoke-GetFile -token $using:token -DeviceIds @($DeviceId) -filePath $using:filePath

                    Write-Host "Invoke-GetFile returned $($results.Count) results for DeviceId: $DeviceId"
                    foreach ($res in $results) {
                        Write-Host "Processing result: $($res | ConvertTo-Json -Compress)"
                        if ($res.Status -eq "Success" -and $res.DownloadUri) {
                            try {
                                $tempFile = [System.IO.Path]::GetTempFileName()
                                $headers = @{ "Authorization" = "Bearer $using:token" }
                                Invoke-WebRequest -Uri $res.DownloadUri -OutFile $tempFile -Headers $headers -UseBasicParsing

                                # Use the original filename from the MDE API if available
                                $originalFileName = if ($res.FileName) { $res.FileName } else { "$DeviceId-$timestamp.zip" }
                                $blobName = $originalFileName

                                $ctx = New-AzStorageContext -StorageAccountName ([System.Environment]::GetEnvironmentVariable('STORAGE_ACCOUNT', 'Process')) -UseConnectedAccount
                                $containerName = "files"
                                Write-Host "Uploading file to Azure Blob Storage: $blobName in container $containerName"
                                Set-AzStorageBlobContent -File $tempFile -Container $containerName -Blob $blobName -Context $ctx -Force

                                Remove-Item $tempFile -Force

                                $output += [PSCustomObject]@{
                                    DeviceId      = $DeviceId
                                    Success       = $true
                                    BlobName      = $blobName
                                    ContainerName = $containerName
                                    DownloadUri   = $res.DownloadUri
                                }
                            } catch {
                                $output += [PSCustomObject]@{
                                    DeviceId    = $DeviceId
                                    Success     = $false
                                    Error       = "Failed to upload file to blob storage: $($_.Exception.Message)"
                                    DownloadUri = $res.DownloadUri
                                }
                            }
                        } else {
                            $output += [PSCustomObject]@{
                                DeviceId    = $DeviceId
                                Success     = $false
                                Error       = $res.Error
                                DownloadUri = $res.DownloadUri
                            }
                        }
                    }
                    return $output
                }
                default {
                    throw "Invalid function specified: $using:Function"
                }
            }
        } catch {
            # Handle and log errors for each device
            Write-Host "Error processing DeviceId: $DeviceId"
            Write-Host "Exception: $($_.Exception.Message)"
            return [PSCustomObject]@{
                DeviceId = $DeviceId
                Success  = $false
                Error    = $_.Exception.Message
            }
        }
    } -ThrottleLimit $throttleLimit

    # No need to flatten, just use the results directly
    $finalResults = $orchestratorResults

    Write-Host "Final Orchestrator Results: $($finalResults | ConvertTo-Json -Depth 100)"

    # Return the results as the HTTP response
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = $finalResults | ConvertTo-Json -Depth 100
    })
}
catch {
    # Handle any unhandled exceptions in the function app
    Write-Host "Unhandled exception: $($_.Exception.Message)"
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::InternalServerError
        Body = "Error executing function: $($_.Exception.Message)"
    })
}


