# Test parameter extraction from string body
# This simulates how Azure Functions passes the request body as a string

Write-Host "=== Testing String Body Parameter Extraction ===" -ForegroundColor Cyan

# Load the Get-RequestParam function from the main script
. ".\run.ps1"

# Create a mock request with string body (like Azure Functions does)
$testJsonString = Get-Content "c:\Git\MDEAutomator\function bodys\MDEAutoChat\test-MDEAutoChat-PSAISuite.json" -Raw

$mockRequest = [PSCustomObject]@{
    Query = @{}
    Body = $testJsonString  # This is how Azure Functions passes it - as a string
}

Write-Host "Mock request created:" -ForegroundColor Yellow
Write-Host "  Body type: $($mockRequest.Body.GetType().Name)" -ForegroundColor Cyan
Write-Host "  Body content: $($mockRequest.Body)" -ForegroundColor Cyan

Write-Host "`nTesting parameter extraction..." -ForegroundColor Yellow

# Test extracting the message parameter
try {
    $message = Get-RequestParam -Name "message" -Request $mockRequest
    if ($message) {
        Write-Host "✓ Successfully extracted 'message': $message" -ForegroundColor Green
    } else {
        Write-Host "✗ Failed to extract 'message' parameter" -ForegroundColor Red
    }
} catch {
    Write-Host "✗ Error extracting 'message': $($_.Exception.Message)" -ForegroundColor Red
}

# Test extracting the system_prompt parameter
try {
    $systemPrompt = Get-RequestParam -Name "system_prompt" -Request $mockRequest
    if ($systemPrompt) {
        Write-Host "✓ Successfully extracted 'system_prompt': $($systemPrompt.Substring(0, [Math]::Min(50, $systemPrompt.Length)))..." -ForegroundColor Green
    } else {
        Write-Host "✗ Failed to extract 'system_prompt' parameter" -ForegroundColor Red
    }
} catch {
    Write-Host "✗ Error extracting 'system_prompt': $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
