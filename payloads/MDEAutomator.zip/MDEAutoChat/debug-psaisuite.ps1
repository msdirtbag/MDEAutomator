# Debug script to test PSAISuite module separately
# Run this script to diagnose PSAISuite issues

param(
    [string]$AzureAIKey = $env:AZURE_AI_KEY,
    [string]$AzureAIEndpoint = $env:AZURE_AI_ENDPOINT,
    [string]$Model = "gpt-4o"
)

Write-Host "=== PSAISuite Debug Script ===" -ForegroundColor Cyan
Write-Host "Testing PSAISuite module and Azure AI connectivity" -ForegroundColor Green

# Check environment variables
Write-Host "`n1. Environment Variables Check:" -ForegroundColor Yellow
Write-Host "AZURE_AI_KEY: $([string]::IsNullOrEmpty($AzureAIKey) ? 'Not set' : 'Set (' + $AzureAIKey.Length + ' chars)')"
Write-Host "AZURE_AI_ENDPOINT: $([string]::IsNullOrEmpty($AzureAIEndpoint) ? 'Not set' : $AzureAIEndpoint)"

if ([string]::IsNullOrEmpty($AzureAIKey) -or [string]::IsNullOrEmpty($AzureAIEndpoint)) {
    Write-Error "Required environment variables are not set. Please set AZURE_AI_KEY and AZURE_AI_ENDPOINT."
    exit 1
}

# Check PSAISuite module
Write-Host "`n2. PSAISuite Module Check:" -ForegroundColor Yellow
try {
    $module = Get-Module -Name PSAISuite -ListAvailable
    if ($module) {
        Write-Host "PSAISuite module found. Version: $($module.Version)" -ForegroundColor Green
    } else {
        Write-Host "PSAISuite module not found. Installing..." -ForegroundColor Orange
        Install-Module -Name PSAISuite -Force -Scope CurrentUser -AllowClobber
        Write-Host "PSAISuite module installed." -ForegroundColor Green
    }
    
    Import-Module -Name PSAISuite -Force
    Write-Host "PSAISuite module imported successfully." -ForegroundColor Green
    
    # List available commands
    $commands = Get-Command -Module PSAISuite
    Write-Host "Available PSAISuite commands ($($commands.Count)):" -ForegroundColor Cyan
    $commands | Sort-Object Name | ForEach-Object { Write-Host "  $($_.Name)" }
    
} catch {
    Write-Error "Failed to load PSAISuite module: $($_.Exception.Message)"
    exit 1
}

# Set environment variables for PSAISuite
Write-Host "`n3. Configure PSAISuite:" -ForegroundColor Yellow
$env:AzureAIKey = $AzureAIKey
$env:AzureAIEndpoint = $AzureAIEndpoint
Write-Host "Environment variables set for PSAISuite." -ForegroundColor Green

# Test message creation
Write-Host "`n4. Test Message Creation:" -ForegroundColor Yellow
try {
    $testPrompt = "Hello, this is a test message for PSAISuite."
    
    # Try different message creation methods
    Write-Host "Testing New-ChatMessage with -Prompt..." -ForegroundColor Cyan
    try {
        $message1 = New-ChatMessage -Prompt $testPrompt
        Write-Host "✓ New-ChatMessage -Prompt succeeded. Type: $($message1.GetType().Name)" -ForegroundColor Green
    } catch {
        Write-Host "✗ New-ChatMessage -Prompt failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Write-Host "Testing New-ChatMessage with -Content..." -ForegroundColor Cyan
    try {
        $message2 = New-ChatMessage -Content $testPrompt
        Write-Host "✓ New-ChatMessage -Content succeeded. Type: $($message2.GetType().Name)" -ForegroundColor Green
    } catch {
        Write-Host "✗ New-ChatMessage -Content failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    # Use the first successful message
    $message = $message1 ?? $message2
    if (-not $message) {
        $message = @{ role = "user"; content = $testPrompt }
        Write-Host "Using manual message creation." -ForegroundColor Orange
    }
    
} catch {
    Write-Error "Failed to create test message: $($_.Exception.Message)"
    exit 1
}

# Test chat completion
Write-Host "`n5. Test Chat Completion:" -ForegroundColor Yellow
try {
    $modelString = "azureai:$Model"
    Write-Host "Testing with model: $modelString" -ForegroundColor Cyan
    
    Write-Host "Calling Invoke-ChatCompletion..." -ForegroundColor Cyan
    $response = Invoke-ChatCompletion -Message $message -Model $modelString -Verbose
    
    if ($response) {
        Write-Host "✓ Chat completion succeeded!" -ForegroundColor Green
        Write-Host "Response type: $($response.GetType().Name)" -ForegroundColor Cyan
        Write-Host "Response properties: $($response.PSObject.Properties.Name -join ', ')" -ForegroundColor Cyan
          # Try to extract content
        $content = $null
        if ($response -is [string]) {
            $content = $response
            Write-Host "Content extracted from string response" -ForegroundColor Green
        } elseif ($response.PSObject.Properties['Response']) {
            $content = $response.Response
            Write-Host "Content extracted from PSAISuite Response property" -ForegroundColor Green
        } elseif ($response.Content) {
            $content = $response.Content
            Write-Host "Content extracted from Content property" -ForegroundColor Green
        } elseif ($response.choices -and $response.choices.Count -gt 0) {
            $content = $response.choices[0].message.content
            Write-Host "Content extracted from OpenAI choices format" -ForegroundColor Green
        } elseif ($response.message) {
            $content = $response.message.content
            Write-Host "Content extracted from message.content" -ForegroundColor Green
        }
        
        if ($content) {
            Write-Host "✓ Content extracted successfully:" -ForegroundColor Green
            Write-Host $content -ForegroundColor White
        } else {
            Write-Host "✗ Could not extract content from response" -ForegroundColor Red
            Write-Host "Full response: $($response | ConvertTo-Json -Depth 3)" -ForegroundColor Gray
        }
    } else {
        Write-Host "✗ Chat completion returned null response" -ForegroundColor Red
    }
    
} catch {
    Write-Host "✗ Chat completion failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Exception type: $($_.Exception.GetType().Name)" -ForegroundColor Gray
    Write-Host "Stack trace: $($_.ScriptStackTrace)" -ForegroundColor Gray
}

# Test direct API call
Write-Host "`n6. Test Direct API Call:" -ForegroundColor Yellow
try {
    $headers = @{
        'Content-Type' = 'application/json'
        'api-key' = $AzureAIKey
    }
    
    $requestBody = @{
        messages = @(
            @{
                role = "user"
                content = "Hello, this is a test message for direct API."
            }
        )
        max_tokens = 100
        temperature = 0.7
    } | ConvertTo-Json -Depth 10
    
    $apiUrl = "$AzureAIEndpoint/openai/deployments/$Model/chat/completions?api-version=2024-02-15-preview"
    Write-Host "Testing direct API call to: $apiUrl" -ForegroundColor Cyan
    
    $directResponse = Invoke-RestMethod -Uri $apiUrl -Method Post -Headers $headers -Body $requestBody -TimeoutSec 30
    
    if ($directResponse) {
        Write-Host "✓ Direct API call succeeded!" -ForegroundColor Green
        if ($directResponse.choices -and $directResponse.choices.Count -gt 0) {
            Write-Host "Direct API response: $($directResponse.choices[0].message.content)" -ForegroundColor White
        }
    } else {
        Write-Host "✗ Direct API call returned null response" -ForegroundColor Red
    }
    
} catch {
    Write-Host "✗ Direct API call failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "HTTP Status: $($_.Exception.Response.StatusCode)" -ForegroundColor Gray
}

Write-Host "`n=== Debug Script Complete ===" -ForegroundColor Cyan
