# Example Base Parameters
param(
    [string]$SpnId = "83a93fb1-5eec-479f-8d96-7ef2330957d3",
    [securestring]$SpnSecret = "bm58Q~6Ug3d1l8q3QDFknmJ9FeL~-87Gp_UXFbS7",
    [string]$TenantId = "b76f6f91-23b8-4aea-b788-80075be331d8"
)

param(
    [string]$SpnId = "83a93fb1-5eec-479f-8d96-7ef2330957d3"
)

param(
    [string]$SpnId = "83a93fb1-5eec-479f-8d96-7ef2330957d3",
    [string]$TenantId = "b76f6f91-23b8-4aea-b788-80075be331d8",
    [string]$keyVaultName = "kv-mdeautomator-dev2354"
)