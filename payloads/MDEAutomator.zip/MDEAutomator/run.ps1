# MDEAutomator Main Function App
# 1.6.0

using namespace System.Net

param($Request)

function Test-NullOrEmpty {
    param (
        [string]$Value,
        [string]$ParamName
    )
    if (-not $Value) {
        throw "Missing required parameter: $ParamName"
    }
}

try {
    # Get request parameters
    $TenantId   = Get-RequestParam -Name "TenantId" -Request $Request
    $Function   = Get-RequestParam -Name "Function" -Request $Request
    $DeviceId   = Get-RequestParam -Name "DeviceId" -Request $Request
    $ActionId   = Get-RequestParam -Name "ActionId" -Request $Request
    $Sha1       = Get-RequestParam -Name "Sha1" -Request $Request
    $Url        = Get-RequestParam -Name "Url" -Request $Request
    $Ip         = Get-RequestParam -Name "Ip" -Request $Request 
    $IncidentId = Get-RequestParam -Name "IncidentId" -Request $Request
    $Comment = Get-RequestParam -Name "Comment" -Request $Request
    $Status = Get-RequestParam -Name "Status" -Request $Request
    $AssignedTo = Get-RequestParam -Name "AssignedTo" -Request $Request
    $Classification = Get-RequestParam -Name "Classification" -Request $Request
    $Determination = Get-RequestParam -Name "Determination" -Request $Request
    $CustomTags = Get-RequestParam -Name "CustomTags" -Request $Request
    $Description = Get-RequestParam -Name "Description" -Request $Request
    $DisplayName = Get-RequestParam -Name "DisplayName" -Request $Request
    $Severity = Get-RequestParam -Name "Severity" -Request $Request
    $ResolvingComment = Get-RequestParam -Name "ResolvingComment" -Request $Request
    $Summary = Get-RequestParam -Name "Summary" -Request $Request
    
    Test-NullOrEmpty $Function "Function"
    
    # TenantId is required for all functions except GetTenantIds
    if ($Function -ne "GetTenantIds") {
        Test-NullOrEmpty $TenantId "TenantId"
    }
    
    # Get environment variables and connect
    $spnId = [System.Environment]::GetEnvironmentVariable('SPNID', 'Process')
    $ManagedIdentityId = [System.Environment]::GetEnvironmentVariable('AZURE_CLIENT_ID', 'Process')

    # Connect to MDE (only for functions that need it)
    $token = $null
    if ($Function -notin @("SaveTenantId", "RemoveTenantId", "GetTenantIds")) {
        $token = Connect-MDE -TenantId $TenantId -SpnId $spnId -ManagedIdentityId $ManagedIdentityId
    }

    $Result = [HttpStatusCode]::OK
    Write-Host "Executing Function: $Function"
    
    $output = switch ($Function) {
        'GetMachines'               { Get-Machines -token $token }
        'GetActions'                { Get-Actions -token $token }
        'GetIncidents'              { Get-Incidents }      
        'GetIncidentAlerts'         { Get-IncidentAlerts -IncidentId $IncidentId }  
        'UpdateIncident'            { 
                                        Test-NullOrEmpty $IncidentId "IncidentId"
                                        Update-Incident -IncidentId $IncidentId -Status $Status -AssignedTo $AssignedTo `
                                                        -Classification $Classification -Determination $Determination -CustomTags $CustomTags `
                                                        -Description $Description -DisplayName $DisplayName -Severity $Severity `
                                                        -ResolvingComment $ResolvingComment -Summary $Summary
                                    }        
        'UpdateIncidentComment'     { 
                                        Test-NullOrEmpty $IncidentId "IncidentId"
                                        Test-NullOrEmpty $Comment "Comment"
                                        Update-IncidentComment -IncidentId $IncidentId -Comment $Comment
                                    }
        'UndoActions'               { Undo-Actions -token $token }
        'GetIPInfo'                 { 
                                        Test-NullOrEmpty $Ip "Ip"
                                        Get-IPInfo -token $token -IPs @($Ip)
                                    }
        'GetFileInfo'               { 
                                        Test-NullOrEmpty $Sha1 "Sha1"
                                        Get-FileInfo -token $token -Sha1s @($Sha1)
                                    }
        'GetURLInfo'                { 
                                        Test-NullOrEmpty $Url "Url"
                                        Get-URLInfo -token $token -URLs @($Url)
                                    }
        'GetLoggedInUsers'          { 
                                        Test-NullOrEmpty $DeviceId "DeviceId"
                                        Get-LoggedInUsers -token $token -DeviceIds @($DeviceId)
                                    }
        'GetMachineActionStatus'    { 
                                        Test-NullOrEmpty $ActionId "ActionId"
                                        Get-MachineActionStatus -machineActionId $ActionId -token $token
                                    }        
        'GetLiveResponseOutput'     { 
                                        Test-NullOrEmpty $ActionId "ActionId"
                                        Get-LiveResponseOutput -machineActionId $ActionId -token $token
                                    }          
        default { throw "Invalid function specified: $Function" }
    }

    $Body = $output | ConvertTo-Json -Depth 100
}
catch {
    $Result = [HttpStatusCode]::InternalServerError
    $Body = "Error executing function: $($_.Exception.Message)"
    Write-Error $_.Exception.Message
}

# Return response
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $Result
    Body = $Body
})